"use client"

export default function PerfilPage() {
  
  return (
   
    <><h1>hola</h1></>
  )
}
