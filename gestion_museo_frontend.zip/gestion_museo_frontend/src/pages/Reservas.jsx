import Calendar from "../components/Calendar"
export default function Reservas() {
  return (
    <>
      <Calendar />
    </>
  )
}
